<?php
	$lang = array(
	'error' => 'Database error: %s',
	'table_not_found' => 'Table "%s" cannot be found in the database. Please make sure you are using the latest version of the database for this version of Ushahidi',
	);
?>
