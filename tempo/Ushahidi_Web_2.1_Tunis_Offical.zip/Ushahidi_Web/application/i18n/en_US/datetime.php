<?php
	$lang = array(
	'am' => 'am',
	'friday' => array(
		'abbv' => 'Fri',
		'full' => 'Friday',
	),
	'monday' => array(
		'abbv' => 'Mon',
		'full' => 'Monday',
	),
	'pm' => 'pm',
	'saturday' => array(
		'abbv' => 'Sat',
		'full' => 'Saturday',
	),
	'sunday' => array(
		'abbv' => 'Sun',
		'full' => 'Sunday',
	),
	'thursday' => array(
		'abbv' => 'Thu',
		'full' => 'Thursday',
	),
	'tuesday' => array(
		'abbv' => 'Tue',
		'full' => 'Tuesday',
	),
	'wednesday' => array(
		'abbv' => 'Wed',
		'full' => 'Wednesday',
	),
	'january' => array(
		'abbv' => 'Jan',
		'full' => 'January',
	),
	'february' => array(
		'abbv' => 'Feb',
		'full' => 'February',
	),
	'march' => array(
		'abbv' => 'Mar',
		'full' => 'March',
	),
	'april' => array(
		'abbv' => 'Apr',
		'full' => 'April',
	),
	'may' => array(
		'abbv' => 'May',
		'full' => 'May',
	),
	'june' => array(
		'abbv' => 'Jun',
		'full' => 'June',
	),
	'july' => array(
		'abbv' => 'Jul',
		'full' => 'July',
	),
	'august' => array(
		'abbv' => 'Aug',
		'full' => 'August',
	),
	'september' => array(
		'abbv' => 'Sep',
		'full' => 'September',
	),
	'october' => array(
		'abbv' => 'Oct',
		'full' => 'October',
	),
	'november' => array(
		'abbv' => 'Nov',
		'full' => 'November',
	),
	'december' => array(
		'abbv' => 'Dec',
		'full' => 'December',
	));
?>
