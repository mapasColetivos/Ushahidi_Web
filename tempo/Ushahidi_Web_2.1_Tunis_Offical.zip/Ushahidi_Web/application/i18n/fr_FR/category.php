<?php
	$lang = array(
	'category_color' => array(
		'length' => 'Le champ «couleur» doit comporter 6 caractères.',
		'required' => 'Veuillez spécifier une couleur.',
	),
	'category_description' => array(
		'required' => 'Veuillez indiquer une description.',
	),
	'category_title' => array(
		'length' => 'Le titre doit comporter entre 3 et 80 caractères.',
		'required' => 'Veuillez indiquer un titre.',
	));
?>
