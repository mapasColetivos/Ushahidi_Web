<?php
	$lang = array(
	);
?>
