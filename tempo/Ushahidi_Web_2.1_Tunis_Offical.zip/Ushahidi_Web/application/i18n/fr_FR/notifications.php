<?php
	$lang = array(
	'admin_footer' => 'Ce message a été envoyé de votre site web',
	'admin_login_url' => 'Login Administrateur',
	'admin_new_comment' => array(
		'message' => 'Un nouveau commentaire vient d\'être envoyé sur votre site, en réponse à:',
		'subject' => 'Nouveau commentaire',
	),
	'admin_new_email' => array(
		'message' => 'Un nouvel email vient d\'être envoyé sur votre site.',
		'subject' => 'Nouvel email',
	),
	'admin_new_report' => array(
		'message' => 'Un nouveau rapport vient d\'être envoyé sur votre site.',
		'subject' => 'Nouveau rapport',
	),
	'admin_new_sms' => array(
		'message' => 'Un nouvel SMS vient d\'être envoyé sur votre site.',
		'subject' => 'Nouveau SMS',
	));
?>
