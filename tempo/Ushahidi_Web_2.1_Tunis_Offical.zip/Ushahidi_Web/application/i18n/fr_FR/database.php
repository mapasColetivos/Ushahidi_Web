<?php
	$lang = array(
	'error' => 'Erreur base de données: %s',
	'table_not_found' => 'Table "%s" non trouvée dans la base de données. Veuillez vérifier que vous utilisez la version correspondante à celle de votre version d\'Ushahidi',
	);
?>
