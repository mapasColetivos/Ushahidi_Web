<?php
	$lang = array(
	'feed_name' => array(
		'length' => 'Le nom du fil doit comporter entre 3 et 70 caractères.',
		'required' => 'Entrez le nom du fil.',
	),
	'feed_url' => array(
		'required' => 'Veuillez entrer l\'URL du fil.',
		'url' => 'Veuillez entrer un URL valide. Ex: http://www.ushahidi.com',
	));
?>
