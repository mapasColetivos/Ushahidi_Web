<?php
	$lang = array(
	'cURL_not_installed' => 'php5-curl n\'est pas installé sur ce système',
	);
?>
