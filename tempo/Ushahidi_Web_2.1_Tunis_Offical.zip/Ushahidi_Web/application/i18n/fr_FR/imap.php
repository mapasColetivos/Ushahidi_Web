<?php
	$lang = array(
	'imap_stream_not_opened' => 'Impossible d\'ouvrir le flux IMAP',
	'unsupported_service' => 'Le service email n\'est pas disponible',
	);
?>
