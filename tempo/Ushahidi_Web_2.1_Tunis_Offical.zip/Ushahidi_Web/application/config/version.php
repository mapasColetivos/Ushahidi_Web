<?php defined('SYSPATH') or die('No direct script access.');
/**
 * The Ushahidi Engine version
 */
$config['ushahidi_version'] = "2.1";


/**
 * The Ushahidi Engine DB revision number
 * Increments when changes are made to the Ushahidi DB schema.
 */
$config['ushahidi_db_version'] = "64";
