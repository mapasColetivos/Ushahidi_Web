<?php defined('SYSPATH') or die('No direct script access.');

// Enable session encryption
$config['name'] = 'ushahidi';
$config['encryption'] = TRUE;