<?php defined('SYSPATH') or die('No direct script access.');

$config['driver'] = 'GD';
$config['params'] = array
(
'directory' => '/usr/local/bin'
);