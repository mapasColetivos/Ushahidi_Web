<?php
print 'mod_rewrite works!';
?>